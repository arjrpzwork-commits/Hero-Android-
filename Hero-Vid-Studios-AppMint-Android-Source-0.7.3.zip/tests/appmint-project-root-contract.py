#!/usr/bin/env python3
"""Fail if the AppMint ZIP root stops being the native Android project root."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
required = [
    "settings.gradle",
    "build.gradle",
    "app/build.gradle",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/assets/editor/index.html",
    "app/src/main/java/com/webapp/herostudios/HeroNativeRuntime.java",
    "app/src/main/cpp/hero_runtime_jni.cpp",
    "app/src/main/cpp/CMakeLists.txt",
    "native-engine/hero_vid_engine/src/main.cpp",
    "build-environment/scripts/build-ffmpeg-android.sh",
]
missing = [path for path in required if not (root / path).is_file()]
if missing:
    raise SystemExit("AppMint project root is incomplete: " + ", ".join(missing))
if (root / "android-project").exists():
    raise SystemExit("Nested android-project directory detected; AppMint must receive the Gradle project at ZIP root")
if (root / "index.html").exists():
    raise SystemExit("Top-level HTML entry point may cause the importer to select a web-only wrapper; use web-preview/ for preview")
java = (root / "app/src/main/java/com/webapp/herostudios/HeroNativeRuntime.java").read_text()
cpp = (root / "app/src/main/cpp/hero_runtime_jni.cpp").read_text()
engine = (root / "native-engine/hero_vid_engine/src/main.cpp").read_text()
assert 'System.loadLibrary("hero_runtime")' in java
assert "Java_com_webapp_herostudios_HeroNativeRuntime_nativeCall" in cpp
assert '"libhero_ffmpeg.so"' in java and '"libhero_ffprobe.so"' in java
assert 'HERO_ANDROID_EMBEDDED=1' in (root / "app/src/main/cpp/CMakeLists.txt").read_text()
assert "fork()" in engine and "execv" in engine
print("PASS: ZIP root is the existing Android Gradle/CMake project; direct JNI and packaged FFmpeg execution paths are included")

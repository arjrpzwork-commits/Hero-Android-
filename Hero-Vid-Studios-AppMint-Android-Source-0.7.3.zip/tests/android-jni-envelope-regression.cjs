const fs = require('fs');
const vm = require('vm');
const html = fs.readFileSync('app/src/main/assets/www/index.html', 'utf8');
const match = html.match(/<script>\s*\/\/ Android bridge adapter:[\s\S]*?<\/script>/);
if (!match) throw new Error('Android bridge adapter script not found');
const script = match[0].replace(/^<script>/, '').replace(/<\/script>$/, '');
let response = JSON.stringify({result:{status:'ok',projectId:'hero-project-test'}});
const window = {HeroRuntime:{
  runtimeInfo:()=>JSON.stringify({status:'loaded',mediaRendererAvailable:true}),
  renderAvailable:()=>true,
  call:()=>response,
  download:()=>JSON.stringify({status:'ok',bytes:12})
}};
vm.runInNewContext(script, {window, JSON, Error, Object});
(async()=>{
  const begun = await window.HeroDesktop.call('beginProject', {});
  if (begun.projectId !== 'hero-project-test') throw new Error('JNI result envelope was not unwrapped');
  response = JSON.stringify({error:{code:-32000,message:'actual FFmpeg failure'}});
  let caught = '';
  try { await window.HeroDesktop.call('renderProject', {}); } catch (e) { caught=e.message; }
  if (caught !== 'actual FFmpeg failure') throw new Error('JNI error envelope was not surfaced: '+caught);
  response = JSON.stringify({result:{status:'ok',outputPath:'/cache/output.mp4'}});
  const rendered = await window.HeroDesktop.call('renderProject', {});
  if (rendered.outputPath !== '/cache/output.mp4') throw new Error('render output path was not unwrapped');
  console.log('PASS: Android JNI success and error envelopes match the editor host contract');
})();

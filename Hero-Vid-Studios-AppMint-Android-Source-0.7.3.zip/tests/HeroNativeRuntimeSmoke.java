import com.webapp.herostudios.HeroNativeRuntime;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

public final class HeroNativeRuntimeSmoke {
    private static void expectOk(String value) {
        if (!value.contains("\"status\":\"ok\"")) throw new AssertionError("Expected success, got: " + value);
    }
    private static void expectError(String value) {
        if (!value.contains("\"status\":\"error\"")) throw new AssertionError("Expected rejection, got: " + value);
    }
    public static void main(String[] args) throws Exception {
        Path root = Files.createTempDirectory("hero-native-stage-test");
        HeroNativeRuntime runtime = new HeroNativeRuntime(root.toString());
        String info = runtime.runtimeInfo();
        if (!info.contains("\"status\":\"loaded\"")) throw new AssertionError("JNI runtime did not load: " + info);
        if (runtime.renderAvailable()) throw new AssertionError("Incomplete engine incorrectly advertised rendering");
        expectOk(runtime.beginProject("project_test"));
        expectOk(runtime.beginSource("project_test", "source_test", "camera.mp4", 6));
        String a = Base64.getEncoder().encodeToString(new byte[]{1,2,3});
        String b = Base64.getEncoder().encodeToString(new byte[]{4,5,6});
        expectOk(runtime.appendSourceChunk("project_test", "source_test", 0, a));
        expectError(runtime.appendSourceChunk("project_test", "source_test", 2, b));
        expectOk(runtime.appendSourceChunk("project_test", "source_test", 1, b));
        expectOk(runtime.finishSource("project_test", "source_test"));
        expectError(runtime.probeSource("project_test", "source_test")); // Host build deliberately has no Android Media NDK.
        Path staged = root.resolve("hero-native/project_test/source_test.media");
        if (Files.size(staged) != 6) throw new AssertionError("Staged file size mismatch");
        expectError(runtime.appendSourceChunk("project_test", "source_test", 2, b));
        expectError(runtime.beginSource("../escape", "bad", "x", 1));
        expectError(runtime.finishSource("project_test", "missing"));
        System.out.println("PASS: JNI loads; ordered source staging, size verification and invalid-request rejection work; rendering remains fail-closed.");
    }
}

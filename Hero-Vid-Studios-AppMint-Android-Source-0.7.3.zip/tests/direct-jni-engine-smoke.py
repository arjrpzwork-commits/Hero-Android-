#!/usr/bin/env python3
"""Host-side exercise of the same C ABI called by HeroNativeRuntime JNI."""
import ctypes
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
JAVA_HOME = Path(os.environ.get("JAVA_HOME", "/usr/lib/jvm/default-java"))
JNI_INCLUDE = JAVA_HOME / "include"
JNI_PLATFORM = JNI_INCLUDE / ("darwin" if os.uname().sysname == "Darwin" else "linux")
if not (JNI_INCLUDE / "jni.h").is_file():
    raise SystemExit("JAVA_HOME must point to a JDK containing include/jni.h")

with tempfile.TemporaryDirectory(prefix="hero-direct-jni-") as temp:
    work = Path(temp)
    shared = work / "libhero_runtime_test.so"
    command = [
        "c++", "-std=c++20", "-O2", "-fPIC", "-shared", "-DHERO_ANDROID_EMBEDDED=1",
        f"-I{JNI_INCLUDE}", f"-I{JNI_PLATFORM}",
        str(ROOT / "app/src/main/cpp/hero_runtime_jni.cpp"),
        str(ROOT / "native-engine/hero_vid_engine/src/main.cpp"),
        "-pthread", "-o", str(shared),
    ]
    subprocess.run(command, check=True)
    native = ctypes.CDLL(str(shared))
    invoke = native.hero_engine_call_json
    invoke.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    invoke.restype = ctypes.c_char_p
    libdir = work / "native-libs"
    libdir.mkdir()
    for name in ("ffmpeg", "ffprobe"):
        executable = shutil.which(name)
        if not executable:
            raise SystemExit(f"Required host test tool not found: {name}")
        (libdir / f"libhero_{name}.so").symlink_to(executable)

    def call(method, params):
        payload = json.dumps(params, separators=(",", ":")).encode()
        response = json.loads(invoke(method.encode(), payload, str(work).encode(), str(libdir).encode()))
        if "error" in response:
            raise RuntimeError(response["error"].get("message", "direct JNI call failed"))
        return response["result"]

    health = call("health", {})
    assert health["status"] == "ok" and health["component"] == "HeroNativeEngine"
    project = {"format": "HeroBrowserSource", "version": 2, "trackCounts": {"video": 1, "audio": 1}, "clips": [
        {"id": "v1", "source": "v", "kind": "video", "track": 0, "start": 0, "in": 0, "out": 2, "gain": 1, "mute": False, "fadeIn": 0, "fadeOut": 0, "layout": "full"},
        {"id": "a1", "source": "a", "kind": "audio", "track": 0, "start": 0, "in": 0, "out": 2, "gain": 1, "mute": False, "fadeIn": 0, "fadeOut": 0},
    ], "audioTrackGains": [1.0], "audioTrackMutes": [False], "audioTrackSolos": [False]}
    settings = {"container": "mp4", "video": True, "video_codec": "h264", "audio_codec": "aac", "width": 640, "height": 360, "fps_num": 30, "fps_den": 1, "video_bitrate": 3000000, "audio_bitrate": 192000, "audio_sample_rate": 48000, "audio_bit_depth": 24, "master_gain": 1.0, "include_original_audio": True, "duration": 2.0}
    created = call("beginProject", {"project": project, "settings": settings})
    project_id = created["projectId"]
    fixtures = ROOT / "native-engine/hero_vid_engine/tests/fixtures"
    for source_id, filename, kind in (("v", "test-source.mp4", "video"), ("a", "test-tone.wav", "audio")):
        media = (fixtures / filename).read_bytes()
        call("beginSource", {"projectId": project_id, "sourceId": source_id, "name": filename, "size": len(media), "kind": kind})
        chunk_size = 256 * 1024
        for sequence, offset in enumerate(range(0, len(media), chunk_size)):
            chunk = media[offset:offset + chunk_size]
            import base64
            call("appendSourceChunk", {"projectId": project_id, "sourceId": source_id, "sequence": sequence, "base64": base64.b64encode(chunk).decode("ascii")})
        call("finishSource", {"projectId": project_id, "sourceId": source_id})
    rendered = call("renderProject", {"projectId": project_id, "settings": settings})
    output = Path(rendered["outputPath"])
    assert rendered["status"] == "ok" and output.is_file() and output.stat().st_size > 0
    metadata = json.loads(subprocess.check_output([shutil.which("ffprobe"), "-v", "error", "-show_entries", "stream=codec_type,codec_name,width,height,sample_rate", "-of", "json", str(output)], text=True))
    assert any(stream.get("codec_name") == "h264" and stream.get("width") == 640 for stream in metadata["streams"])
    assert any(stream.get("codec_name") == "aac" and stream.get("sample_rate") == "48000" for stream in metadata["streams"])
    print("PASS: in-process JNI C++ engine stages media, renders MP4 through FFmpeg, and verifies output with FFprobe")

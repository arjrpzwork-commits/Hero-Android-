from pathlib import Path

root = Path(__file__).resolve().parents[1]
gradle = (root / "app/build.gradle").read_text()
activity = (root / "app/src/main/java/com/webapp/herostudios/MainActivity.java").read_text()
java = (root / "app/src/main/java/com/webapp/herostudios/HeroNativeRuntime.java").read_text()
cpp = (root / "app/src/main/cpp/hero_runtime_jni.cpp").read_text()
cmake = (root / "app/src/main/cpp/CMakeLists.txt").read_text()
editor = (root / "app/src/main/assets/editor/index.html").read_text()
engine = (root / "native-engine/hero_vid_engine/src/main.cpp").read_text()

assert "externalNativeBuild" in gradle and "src/main/cpp/CMakeLists.txt" in gradle
assert "ndkVersion '27.2.12479018'" in gradle
assert 'add_library(hero_runtime SHARED hero_runtime_jni.cpp' in cmake
assert 'hero_vid_engine/src/main.cpp' in cmake and 'HERO_ANDROID_EMBEDDED=1' in cmake
assert 'add_executable(hero_native_engine' not in cmake
assert 'System.loadLibrary("hero_runtime")' in java
assert 'addJavascriptInterface(nativeRuntime, "HeroRuntime")' in activity
assert 'file:///android_asset/editor/index.html' in activity
assert 'Java_com_webapp_herostudios_HeroNativeRuntime_nativeCall' in cpp
assert 'hero_engine_call_json' in cpp and 'hero_engine_call_json' in engine
assert 'window.HeroDesktop = {' in editor
assert 'native.call(method, JSON.stringify(params || {}))' in editor
assert 'native.download(path)' in editor
assert 'mediaRendererAvailable' in java and 'engineReady()' in java
assert 'nativeCall(method,paramsJson' in java
assert 'ProcessBuilder' not in java and 'verifyEngineLaunch' not in java
assert 'renderProject' in engine and 'ffmpeg_' in engine and 'method == \"health\"' in engine
assert 'verify_output' in engine and 'ffprobe' in engine
assert 'jniLibs/${ANDROID_ABI}' not in cmake
assert 'useLegacyPackaging = true' in gradle
assert 'verify-android-native-executables.sh' in (root / '.github/workflows/android-build.yml').read_text()
assert 'android:extractNativeLibs="true"' in (root / 'app/src/main/AndroidManifest.xml').read_text()
assert 'build-ffmpeg-android.sh' in gradle
assert gradle.count('workingDir rootProject.projectDir') == 2
ffmpeg_build=(root / 'build-environment/scripts/build-ffmpeg-android.sh').read_text()
assert 'gpg --batch --verify' in ffmpeg_build and 'ffmpeg-devel.asc' in ffmpeg_build
assert 'libhero_engine.so' not in java
assert 'libhero_ffmpeg.so' in java and 'libhero_ffprobe.so' in java
assert 'getApplicationInfo().nativeLibraryDir' in java
assert 'direct-jni-engine-call' in java
assert 'MediaStore.Video.Media.EXTERNAL_CONTENT_URI' in java
assert 'MediaStore.Audio.Media.EXTERNAL_CONTENT_URI' in java
assert 'Split-screen layout is not yet implemented' in engine
assert 'std::uint64_t{1} << 40' not in engine
assert 'channel_layouts=stereo' not in engine
assert 'length>1024*1024' not in cpp
assert 'no browser recording fallback' in editor
assert 'MediaRecorder' not in editor and 'captureStream' not in editor
print('PASS: Android editor -> Java bridge -> C++ timeline renderer -> FFmpeg/FFprobe -> MediaStore contract')

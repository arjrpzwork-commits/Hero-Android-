#!/usr/bin/env python3
"""Build and exercise the actual C++ timeline renderer against generated media."""
import base64
import json
import os
import shutil
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ENGINE_SRC = ROOT / "native-engine/hero_vid_engine/src/main.cpp"

def run(command):
    subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

def main():
    with tempfile.TemporaryDirectory(prefix="hero-render-test-") as temp:
        work = Path(temp)
        binary = work / "hero-native-engine"
        video = work / "source.mp4"
        audio = work / "audio.wav"
        run(["c++", "-std=c++20", "-O2", "-Wall", "-Wextra", "-Wpedantic", str(ENGINE_SRC), "-o", str(binary)])
        run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=30:duration=2", "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000:duration=2", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", str(video)])
        run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "sine=frequency=880:sample_rate=48000:duration=2", "-c:a", "pcm_s24le", str(audio)])
        env = os.environ.copy()
        env["HERO_FFMPEG"] = shutil.which("ffmpeg") or "ffmpeg"
        env["HERO_FFPROBE"] = shutil.which("ffprobe") or "ffprobe"
        proc = subprocess.Popen([str(binary)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1, env=env)
        def call(method, params):
            proc.stdin.write(json.dumps({"id": method, "method": method, "params": params}) + "\n")
            proc.stdin.flush()
            response = json.loads(proc.stdout.readline())
            if "error" in response:
                raise RuntimeError(response["error"].get("message", "renderer request failed"))
            return response["result"]
        def stage(project_id, source_id, path):
            size = path.stat().st_size
            call("beginSource", {"projectId": project_id, "sourceId": source_id, "name": path.name, "size": size})
            with path.open("rb") as stream:
                sequence = 0
                while chunk := stream.read(256 * 1024):
                    call("appendSourceChunk", {"projectId": project_id, "sourceId": source_id, "sequence": sequence, "base64": base64.b64encode(chunk).decode("ascii")})
                    sequence += 1
            call("finishSource", {"projectId": project_id, "sourceId": source_id})
        try:
            health = call("health", {})
            assert health["status"] == "ok" and health["component"] == "HeroNativeEngine"
            settings = {"container": "mp4", "video": True, "video_codec": "h264", "audio_codec": "aac", "width": 640, "height": 360, "fps_num": 30, "fps_den": 1, "video_bitrate": 3000000, "audio_bitrate": 192000, "audio_sample_rate": 48000, "audio_bit_depth": 24, "master_gain": 1.0, "include_original_audio": True, "duration": 2.0}
            project = {"format": "HeroBrowserSource", "version": 2, "trackCounts": {"video": 2, "audio": 1}, "clips": [
                {"id": "v1", "source": "v", "kind": "video", "track": 0, "start": 0, "in": 0, "out": 2, "gain": 1, "mute": False, "fadeIn": 0, "fadeOut": 0, "layout": "full"},
                {"id": "v2", "source": "v", "kind": "video", "track": 1, "start": 0.5, "in": 0, "out": 1, "gain": 1, "mute": False, "fadeIn": 0, "fadeOut": 0, "layout": "pip", "pipScale": 0.3, "pipX": 70, "pipY": 70, "brightness": 110, "contrast": 100, "saturation": 100},
                {"id": "a1", "source": "a", "kind": "audio", "track": 0, "start": 0, "in": 0, "out": 2, "gain": 0.5, "mute": False, "fadeIn": 0, "fadeOut": 0, "automation": [{"time": 0, "gain": 0.2}, {"time": 1, "gain": 1.0}]}
            ], "audioTrackGains": [0.8], "audioTrackMutes": [False], "audioTrackSolos": [False]}
            project_id = call("beginProject", {"project": project, "settings": settings})["projectId"]
            stage(project_id, "v", video)
            stage(project_id, "a", audio)
            rendered = call("renderProject", {"projectId": project_id, "settings": settings})
            metadata = json.loads(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,codec_name,width,height,sample_rate", "-of", "json", rendered["outputPath"]], text=True))
            v = next(s for s in metadata["streams"] if s["codec_type"] == "video")
            a = next(s for s in metadata["streams"] if s["codec_type"] == "audio")
            assert (v["codec_name"], v["width"], v["height"]) == ("h264", 640, 360)
            assert (a["codec_name"], a["sample_rate"]) == ("aac", "48000")
            print("PASS: multi-clip native MP4 render, PIP, color adjustment, audio automation, ffprobe verification")
            invalid = dict(project)
            invalid["clips"] = [dict(project["clips"][1], pipScale=0.99)]
            bad_id = call("beginProject", {"project": invalid, "settings": settings})["projectId"]
            stage(bad_id, "v", video)
            try:
                call("renderProject", {"projectId": bad_id, "settings": settings})
            except RuntimeError as error:
                assert "outside the editor's selected control range" in str(error)
                print("PASS: unsupported/out-of-range PIP settings fail explicitly; no silent clamp")
            else:
                raise AssertionError("Out-of-range PIP setting was silently accepted")
            wav_settings = {"container": "wav", "video": False, "video_codec": "h264", "audio_codec": "pcm", "width": 640, "height": 360, "fps_num": 30, "fps_den": 1, "video_bitrate": 3000000, "audio_bitrate": 192000, "audio_sample_rate": 96000, "audio_bit_depth": 24, "master_gain": 1.0, "include_original_audio": True, "duration": 2.0}
            wav_project = {"format": "HeroBrowserSource", "version": 2, "trackCounts": {"video": 1, "audio": 1}, "clips": [
                {"id": "a96", "source": "a", "kind": "audio", "track": 0, "start": 0, "in": 0, "out": 2, "gain": 1, "mute": False, "fadeIn": 0, "fadeOut": 0}
            ], "audioTrackGains": [1.0], "audioTrackMutes": [False], "audioTrackSolos": [False]}
            wav_id = call("beginProject", {"project": wav_project, "settings": wav_settings})["projectId"]
            stage(wav_id, "a", audio)
            wav_render = call("renderProject", {"projectId": wav_id, "settings": wav_settings})
            wav_meta = json.loads(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=format_name,duration:stream=codec_name,sample_rate,channels,bits_per_sample,bits_per_raw_sample", "-of", "json", wav_render["outputPath"]], text=True))
            wav_stream = next(stream for stream in wav_meta["streams"] if stream["codec_name"].startswith("pcm_"))
            assert "wav" in wav_meta["format"]["format_name"]
            assert wav_stream["codec_name"] == "pcm_s24le"
            assert wav_stream["sample_rate"] == "96000" and wav_stream["bits_per_raw_sample"] == "24"
            assert wav_stream["channels"] == 1, "renderer unexpectedly forced mono source to stereo"
            print("PASS: audio-only WAV preserves mono layout and verifies 96 kHz / 24-bit PCM")
        finally:
            proc.stdin.close()
            proc.wait(timeout=30)
            if proc.returncode != 0:
                raise RuntimeError(proc.stderr.read()[-2000:])

if __name__ == "__main__":
    main()

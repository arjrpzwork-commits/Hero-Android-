#!/usr/bin/env python3
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
gradle = (root / 'app/build.gradle').read_text()
java = (root / 'app/src/main/java/com/webapp/herostudios/MainActivity.java').read_text()
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()
assert "applicationId 'com.webapp.herostudios'" in gradle
assert "namespace 'com.webapp.herostudios'" in gradle
assert 'versionCode 15' in gradle and "versionName '0.5.14'" in gradle
assert 'package com.webapp.herostudios;' in java
assert 'file:///android_asset/editor/index.html' in java
assert 'assetExists("editor/index.html")' in java
assert 'showStartupError(' in java and 'Retry opening editor' in java
assert 'file:///android_asset/' in java
assert 'android:name=".MainActivity"' in manifest
assert (root / 'app/src/main/assets/editor/index.html').is_file()
print('PASS: Android package identity, version, bundled editor, startup diagnostics and launcher contract')

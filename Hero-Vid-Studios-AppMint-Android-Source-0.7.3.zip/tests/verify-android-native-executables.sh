#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ -n "${ANDROID_NDK_HOME:-}" ]]; then
  NDK="$ANDROID_NDK_HOME"
else
  SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
  [[ -n "$SDK" ]] || { echo 'ANDROID_SDK_ROOT/ANDROID_HOME is required for native package verification' >&2; exit 2; }
  NDK="$SDK/ndk/27.2.12479018"
fi
READELF="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-readelf"
[[ -x "$READELF" ]] || { echo "Android NDK llvm-readelf not found: $READELF" >&2; exit 2; }
DIR="app/src/main/jniLibs/arm64-v8a"
for name in libhero_ffmpeg.so libhero_ffprobe.so; do
  file="$DIR/$name"
  test -s "$file" || { echo "Missing built Android FFmpeg executable: $file" >&2; exit 1; }
  test -x "$file" || { echo "Android FFmpeg executable bit missing: $file" >&2; exit 1; }
  "$READELF" -h "$file" | grep -Eq 'Type:.*DYN' || { echo "$name is not a PIE/ET_DYN executable" >&2; exit 2; }
  "$READELF" -l "$file" | grep -q 'INTERP' || { echo "$name has no Android dynamic linker interpreter" >&2; exit 3; }
done

APKS=("app/build/outputs/apk/debug/app-debug.apk" "app/build/outputs/apk/release/app-release-unsigned.apk")
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
for APK in "${APKS[@]}"; do
  test -s "$APK" || { echo "Expected APK is missing: $APK" >&2; exit 4; }
  DEST="$TMP/$(basename "$(dirname "$APK")")"
  mkdir -p "$DEST"
  for name in libhero_runtime.so libhero_ffmpeg.so libhero_ffprobe.so; do
    unzip -p "$APK" "lib/arm64-v8a/$name" > "$DEST/$name"
    test -s "$DEST/$name" || { echo "$APK is missing lib/arm64-v8a/$name" >&2; exit 5; }
  done
  "$READELF" -h "$DEST/libhero_runtime.so" | grep -Eq 'Type:.*DYN' || { echo "$APK JNI library is not ET_DYN" >&2; exit 6; }
  for name in libhero_ffmpeg.so libhero_ffprobe.so; do
    "$READELF" -h "$DEST/$name" | grep -Eq 'Type:.*DYN' || { echo "$APK $name is not PIE/ET_DYN" >&2; exit 7; }
    "$READELF" -l "$DEST/$name" | grep -q 'INTERP' || { echo "$APK $name has no Android dynamic linker interpreter" >&2; exit 8; }
  done
  echo "PASS: $APK contains JNI renderer and both Android PIE tools."
done

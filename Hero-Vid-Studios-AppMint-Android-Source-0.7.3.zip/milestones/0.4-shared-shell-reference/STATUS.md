# Milestone 0.4 — Shared shell / metadata (reconstructed)

The original 0.4 source modules named in the 0.5 manifest were not present in the recovered Library. This rebuild supplies a dependency-free project schema module (`app/src/main/assets/editor/project-schema.js`) and integrates it with save, restore and pre-render validation. The recovered themed HTML is retained here as a visual/source reference only; it is not misrepresented as the missing 0.4 source.

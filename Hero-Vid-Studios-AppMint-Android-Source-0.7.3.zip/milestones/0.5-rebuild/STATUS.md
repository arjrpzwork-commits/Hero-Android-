# Milestone 0.5 — Unified rebuild candidate

This is a fresh reconstruction using the preserved 0.2 editing workspace, the recovered C++20 native media engine foundation, and a strict platform contract. It unifies project metadata validation, precommit source resolution, busy-state editing locks already present in the editor, and native output verification requirements.

The native C++ engine builds and its Linux smoke tests pass in this environment. It remains a POSIX/Linux executable requiring external FFmpeg/ffprobe and Boost. It is NOT yet integrated into Android or desktop host applications. The Android project includes the editor and native-engine source continuity; it does not ship an Android native renderer.

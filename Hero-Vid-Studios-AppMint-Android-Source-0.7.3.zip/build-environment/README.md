# Android native build environment

The Android Gradle project is rooted at the top of this package. Run all commands from the directory containing `settings.gradle`; there is no nested `android-project/` folder.

`app/build.gradle` prepares the pinned Boost headers, verifies the FFmpeg 7.1.1 upstream PGP signature, builds FFmpeg/FFprobe for `arm64-v8a`, and invokes Android CMake/NDK.

CMake compiles both `app/src/main/cpp/hero_runtime_jni.cpp` and `native-engine/hero_vid_engine/src/main.cpp` into **one shared JNI library**, `libhero_runtime.so`. The JavaScript editor calls the C++ timeline engine in-process through `HeroNativeRuntime.nativeCall()`; there is no standalone `hero_engine` process and no `ProcessBuilder` launch.

The FFmpeg build creates two Android PIE executables named `libhero_ffmpeg.so` and `libhero_ffprobe.so` under `app/src/main/jniLibs/<abi>/`. Android Package Manager extracts these packaged native-library-directory files. The C++ engine invokes them using their absolute paths from `nativeLibraryDir`; it never copies executable code into writable app storage. `useLegacyPackaging = true` and `android:extractNativeLibs="true"` are required by this packaging approach.

Run the Android build with the pinned Android SDK/NDK and Gradle versions described in the workflow. The Android build and device test remain outstanding until the workflow produces APK artifacts and an actual device export is verified.

# Hero Native Media Engine — foundation 0.1

This is a separate native-engine development milestone. It does **not** modify or replace any Hero Vid Studios HTML build.

## What exists in this milestone

- A C++20 native process with a line-delimited JSON request/response protocol.
- Source-media staging in ordered chunks with byte-count verification before render.
- Offline FFmpeg rendering outside the browser.
- Basic video timeline composition: source in/out trim, timeline start, track ordering, scale/pad to the requested frame size, and frame-rate conversion.
- Basic audio timeline processing: source trim, timeline delay, clip gain, master gain, fades, sample-rate conversion, and multi-clip mixing.
- Codec/container selection for the implemented FFmpeg encoder names; unsupported encoder builds fail instead of falling back silently.
- Post-render ffprobe verification for requested video codec, dimensions, frame rate, audio codec, sample rate, and PCM bit depth.
- Separate WAV/PCM rendering, tested at 96 kHz / 24-bit.

## What is not connected or complete yet

- The existing Hero Vid Studios page is **not connected** to this executable. Its `window.HeroNative` object still needs a desktop/mobile host adapter that forwards the five methods below to this process.
- No production desktop shell, Android service, installer, native playback device layer, or native preview is included.
- Progress streaming and user cancellation are not implemented in this first executable protocol.
- No transitions, titles, effects stack, color-management pipeline, HDR pipeline, proxy workflow, waveform cache, or complete multi-track audio automation yet.
- A video source with no audio stream will fail if “include original video audio” is enabled for that clip. Disable original audio for such sources until stream-aware source probing is added.
- The test suite is a focused smoke test, not full editor regression or professional certification.
- The current process launcher uses POSIX APIs. macOS/Linux/Android porting is the immediate target; Windows process-launch support remains to be added before a Windows build.

## Build

Requirements: CMake 3.20+, C++20 compiler, Boost headers (Property Tree), and `ffmpeg` / `ffprobe` on PATH.

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

Run the executable as a persistent child process and communicate over stdin/stdout, one JSON object per line. Standard output is reserved for JSON responses.

## Native bridge protocol

Each request has `id`, `method`, and `params`. The response has the same `id` and either `result` or `error`.

1. `beginProject({ project, settings })` → `{ projectId }`
2. `beginSource({ projectId, sourceId, name, size, kind })`
3. `appendSourceChunk({ projectId, sourceId, sequence, base64 })`
4. `finishSource({ projectId, sourceId })` — confirms exact byte count.
5. `renderProject({ projectId, settings })` → output path and ffprobe metadata.

Chunk size can match the current page's 256 KiB. Sequence numbers start at zero and must be contiguous. The host must not report a successful export until `renderProject` returns `status: "ok"`.

The existing page's `window.HeroNative` API has the same method names and parameter shapes. A native host adapter still has to implement those methods and translate the returned filesystem path into a user-accessible file URL / save dialog result.

## Quality and no-silent-downgrade policy

The engine validates settings before encoding and probes the completed file afterward. A mismatch in requested codec, dimensions, frame rate, sample rate, or PCM bit depth returns an error instead of success. AAC/Opus/MP3 are lossy codecs; PCM bit depth is only meaningful for PCM output. The video bitrate is passed to FFmpeg as the target bitrate; the measured average stream bitrate can differ because encoders use variable bitrate.

The engine does not claim bit-transparent video processing. Video is decoded, composited, scaled/padded and re-encoded. Audio is decoded, mixed, gain/fade processed and resampled to the selected output rate. This is a real processing pipeline, not byte-for-byte passthrough.

## FFmpeg licensing and distribution gate

This source invokes external `ffmpeg` and `ffprobe`; it does not bundle either binary. The FFmpeg executable available in the development container reports a build configured with `--enable-gpl` and `--enable-libx264`. **That exact development FFmpeg build must not be copied into a distribution represented as LGPL-only.** Before shipping, choose and audit a specific FFmpeg build, its configure flags, every enabled external library/encoder, source-offer and notice obligations, and platform packaging. Some popular encoder libraries change FFmpeg's license obligations. This milestone makes no blanket legal clearance claim.

The engine source is original project code. It uses Boost Property Tree headers under the Boost Software License 1.0; include the required license notice in any source distribution that includes Boost material.

## Test

After building, run:

```bash
python3 tests/test_smoke.py --engine build/hero-native-engine
```

The script exercises one MP4/H.264/AAC offline video render and one 96 kHz / 24-bit PCM WAV render, then checks the resulting stream metadata with ffprobe.

For ProRes 422 HQ, this build selects the ProRes HQ profile and 10-bit 4:2:2 pixel format. For FFV1, the output is lossless relative to the decoded/composited render. The Mbps target is not a meaningful control for ProRes/FFV1; the render result explicitly reports that limitation rather than pretending the target was applied.

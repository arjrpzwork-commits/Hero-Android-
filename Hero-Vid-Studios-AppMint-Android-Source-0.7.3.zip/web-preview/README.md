# Hero Vid Studios web preview

This file is a visual/reference copy of the editor HTML. It is **not** the Android application build entry point and does not include the native C++ renderer. The Android APK must be built from the project root containing `settings.gradle`, `build.gradle`, and `app/`.

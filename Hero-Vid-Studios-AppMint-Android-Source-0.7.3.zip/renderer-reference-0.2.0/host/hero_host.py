#!/usr/bin/env python3
"""Local, no-subscription launcher for the Hero Render Engine host service."""
from __future__ import annotations
import argparse, json, os, secrets, signal, socket, subprocess, sys, time, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = Path(os.environ.get('HERO_RENDER_DATA', str(ROOT / 'data'))).resolve()
RUNTIME = ROOT / '.runtime'
LOGS = RUNTIME / 'logs'
VENV = ROOT / '.venv'
PY = VENV / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
ENGINE = ROOT / 'engine' / 'build' / 'hero-native-engine'


def run(cmd: list[str], **kw):
    print('+', ' '.join(map(str, cmd)), flush=True)
    subprocess.run(cmd, check=True, cwd=ROOT, **kw)


def setup():
    if os.name == 'nt':
        raise SystemExit('This engine build currently uses POSIX process APIs. Use a macOS or Linux host for this milestone; Windows support is not yet implemented.')
    for tool in ('cmake', 'c++', 'ffmpeg', 'ffprobe'):
        from shutil import which
        if not which(tool): raise SystemExit(f'Missing required host dependency: {tool}')
    run([sys.executable, '-m', 'venv', str(VENV)])
    run([str(PY), '-m', 'pip', 'install', '--upgrade', 'pip'])
    run([str(PY), '-m', 'pip', 'install', '-r', str(ROOT / 'service' / 'requirements.txt')])
    run(['cmake', '-S', str(ROOT / 'engine'), '-B', str(ROOT / 'engine' / 'build'), '-DCMAKE_BUILD_TYPE=Release'])
    run(['cmake', '--build', str(ROOT / 'engine' / 'build'), '--config', 'Release', '-j', str(max(1, os.cpu_count() or 2))])
    DATA.mkdir(parents=True, exist_ok=True); LOGS.mkdir(parents=True, exist_ok=True)
    token_file = RUNTIME / 'access-token.txt'
    if not token_file.exists():
        RUNTIME.mkdir(parents=True, exist_ok=True)
        token_file.write_text(secrets.token_urlsafe(48), encoding='utf-8')
        try: token_file.chmod(0o600)
        except OSError: pass
    print('\nSetup complete. Your access token is stored locally in .runtime/access-token.txt')


def pid_alive(pid: int) -> bool:
    try: os.kill(pid, 0); return True
    except OSError: return False


def start_one(name: str, cmd: list[str], env: dict[str, str]):
    RUNTIME.mkdir(parents=True, exist_ok=True); LOGS.mkdir(parents=True, exist_ok=True)
    pf = RUNTIME / f'{name}.pid'
    if pf.exists():
        try:
            if pid_alive(int(pf.read_text().strip())):
                print(f'{name} already running (PID {pf.read_text().strip()})'); return
        except Exception: pass
        pf.unlink(missing_ok=True)
    log = (LOGS / f'{name}.log').open('ab', buffering=0)
    p = subprocess.Popen(cmd, cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    pf.write_text(str(p.pid), encoding='utf-8')
    print(f'{name} started (PID {p.pid})')


def start():
    if not PY.exists() or not ENGINE.exists(): raise SystemExit('Run setup first: python3 host/hero_host.py setup')
    token_file = RUNTIME / 'access-token.txt'
    if not token_file.exists(): raise SystemExit('Missing local access token; run setup again.')
    env = os.environ.copy(); env.update({'HERO_RENDER_DATA': str(DATA), 'HERO_ENGINE_BIN': str(ENGINE), 'HERO_RENDER_TOKEN': token_file.read_text().strip(), 'PYTHONPATH': str(ROOT)})
    start_one('worker', [str(PY), str(ROOT / 'worker' / 'worker.py')], env)
    start_one('api', [str(PY), '-m', 'uvicorn', 'service.app:app', '--host', '127.0.0.1', '--port', '8080'], env)
    for _ in range(30):
        try:
            with urllib.request.urlopen('http://127.0.0.1:8080/health', timeout=1) as r:
                print('Hero Render Engine:', r.read().decode()); return
        except Exception: time.sleep(.5)
    print('Processes started, but health check did not respond. Inspect .runtime/logs/api.log and worker.log.')


def stop():
    for name in ('api', 'worker'):
        pf = RUNTIME / f'{name}.pid'
        if not pf.exists(): print(f'{name}: not running'); continue
        try:
            pid = int(pf.read_text().strip()); os.kill(pid, signal.SIGTERM); print(f'{name}: stop requested (PID {pid})')
        except ProcessLookupError: print(f'{name}: already stopped')
        except Exception as e: print(f'{name}: {e}')
        pf.unlink(missing_ok=True)


def status():
    for name in ('api', 'worker'):
        pf = RUNTIME / f'{name}.pid'
        if pf.exists():
            try: print(f'{name}: '+('running' if pid_alive(int(pf.read_text().strip())) else 'stopped'))
            except Exception: print(f'{name}: unknown')
        else: print(f'{name}: stopped')
    try:
        with urllib.request.urlopen('http://127.0.0.1:8080/health', timeout=2) as r: print('API:', r.read().decode())
    except Exception: print('API: unavailable')

if __name__ == '__main__':
    ap=argparse.ArgumentParser(description='Hero Render Engine local host manager'); ap.add_argument('command',choices=['setup','start','stop','status']); a=ap.parse_args()
    {'setup':setup,'start':start,'stop':stop,'status':status}[a.command]()

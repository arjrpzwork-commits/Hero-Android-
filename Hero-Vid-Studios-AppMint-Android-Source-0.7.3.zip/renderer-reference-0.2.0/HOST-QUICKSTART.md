# Hero Render Engine 0.2.0 — local host quick start

This milestone adds a no-subscription local host runner and a disk-streaming export client around the existing independent Hero render service. It does **not** modify the accepted Android 0.5.12 package or claim that the editor's Export button is already wired to this service.

## Host requirements

For this milestone, use a **macOS or Linux computer** that stays powered on during rendering. Windows is not supported by the current C++ engine process implementation. Required free host tools: Python 3.10+, CMake 3.20+, a C++20 compiler, Boost headers, FFmpeg and ffprobe. The setup command builds the native engine and installs the Python service dependencies into a local virtual environment.

## Start

From this folder:

```bash
python3 host/hero_host.py setup
python3 host/hero_host.py start
python3 host/hero_host.py status
```

The API listens on `127.0.0.1:8080` only. The worker and API run as separate local processes. Jobs, source media, cache/workspace and outputs are disk-backed under `data/`; logs and a generated bearer token are under `.runtime/`. Keep this folder on a drive with enough free space. Do not delete `data/` while jobs or exports are needed.

Stop with `python3 host/hero_host.py stop`. The computer must remain awake and powered while a render is running. The editor/browser may be closed after the job has been submitted.

## Submit an export

Create a JSON manifest containing `project`, `settings`, and `sources`. Each source requires `id`, `name`, `kind`, and `size` (exact bytes). Put one media file per source in a folder, named `<source-id>.<extension>`. The project clip source IDs must match the manifest source IDs.

Set the token from `.runtime/access-token.txt` in the `HERO_RENDER_TOKEN` environment variable, then run:

```bash
HERO_RENDER_TOKEN="$(cat .runtime/access-token.txt)" \
python3 tools/hero_export.py \
  --manifest /path/to/export-manifest.json \
  --media-dir /path/to/original-media \
  --output /path/to/Hero-Export.mp4
```

The client uploads media in 1 MiB chunks directly to the host, polls job status, and streams the completed file to disk. It does not read all media into RAM. It prints the verified output metadata returned by the engine.

## Important boundaries for tonight

- This is a local host renderer; it is not a paid cloud service.
- API binds to localhost by default; it is not exposed to the internet or LAN.
- The existing native engine supports basic timeline video clip composition and audio mixing, not every effect or transition in the editor.
- The current engine still uses FFmpeg/ffprobe as local encoding tools. Their exact build and licensing must be audited before commercial redistribution; this package does not claim legal clearance.
- The current editor milestone is not yet connected. The remaining integration is a native host adapter that exports the editor's project snapshot and media into this manifest/API contract, then imports the completed output into Hero's project/export storage.
- No fixed product-level file-size, duration, resolution or bitrate caps are added. Actual disk capacity, host resources and format/codec support remain physical constraints.

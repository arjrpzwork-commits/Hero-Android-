#!/usr/bin/env python3
"""Stream a Hero export manifest and media to a local Hero Render Engine host."""
from __future__ import annotations
import argparse, http.client, json, mimetypes, os, sys, time, urllib.parse, uuid
from pathlib import Path
CHUNK=1024*1024

def main():
    p=argparse.ArgumentParser(description='Submit a project manifest and media to Hero Render Engine')
    p.add_argument('--manifest',required=True,help='JSON file containing project, settings, and sources[]')
    p.add_argument('--media-dir',required=True,help='Folder containing source files named by source id')
    p.add_argument('--url',default='http://127.0.0.1:8080')
    p.add_argument('--token',default=os.environ.get('HERO_RENDER_TOKEN'))
    p.add_argument('--output',default='Hero-Export.mp4')
    p.add_argument('--poll',type=float,default=2.0)
    a=p.parse_args()
    if not a.token: sys.exit('Set HERO_RENDER_TOKEN or provide it through the environment.')
    spec=json.loads(Path(a.manifest).read_text(encoding='utf-8')); sources=spec.get('sources') or []
    if not sources: sys.exit('Manifest must contain at least one source.')
    boundary='----HeroRender'+uuid.uuid4().hex
    parts=[]; files=[]; total=0
    def field(name,value):
        b=(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode(); parts.append(b)
    field('manifest',json.dumps(spec,separators=(',',':')))
    media_dir=Path(a.media_dir)
    for s in sources:
        sid=str(s['id']); candidates=list(media_dir.glob(sid+'.*'))
        if len(candidates)!=1: sys.exit(f'Expected exactly one file named {sid}.* in {media_dir}; found {len(candidates)}')
        f=candidates[0]; size=f.stat().st_size
        if int(s.get('size',size))!=size: sys.exit(f'Size mismatch in manifest for {sid}: {s.get("size")} vs {size}')
        s['size']=size; ext=f.suffix or '.bin'; filename=sid+ext
        head=(f'--{boundary}\r\nContent-Disposition: form-data; name="media"; filename="{filename}"\r\nContent-Type: {mimetypes.guess_type(filename)[0] or "application/octet-stream"}\r\n\r\n').encode()
        tail=b'\r\n'; parts.append(head); files.append((f,tail)); total+=len(head)+size+len(tail)
    end=f'--{boundary}--\r\n'.encode()
    # Exact multipart length; media bytes are streamed later and never buffered.
    bodylen=sum(len(b) for b in parts)+sum(f.stat().st_size+len(tail) for f,tail in files)+len(end)
    u=urllib.parse.urlsplit(a.url); conn=(http.client.HTTPSConnection(u.hostname,u.port,timeout=60) if u.scheme=='https' else http.client.HTTPConnection(u.hostname,u.port or 80,timeout=60))
    path=(u.path.rstrip('/') or '')+'/v1/jobs'
    conn.putrequest('POST',path); conn.putheader('Authorization','Bearer '+a.token); conn.putheader('Content-Type','multipart/form-data; boundary='+boundary); conn.putheader('Content-Length',str(bodylen)); conn.endheaders()
    for b in parts: conn.send(b)
    for f,tail in files:
        with f.open('rb') as stream:
            while chunk:=stream.read(CHUNK): conn.send(chunk)
        conn.send(tail)
    conn.send(end); response=conn.getresponse(); payload=response.read()
    if response.status!=202: sys.exit(f'Job submission failed ({response.status}): {payload.decode(errors="replace")}')
    job=json.loads(payload); jid=job['job_id']; print('Queued:',jid,flush=True)
    while True:
        conn.close(); conn=(http.client.HTTPSConnection(u.hostname,u.port,timeout=60) if u.scheme=='https' else http.client.HTTPConnection(u.hostname,u.port or 80,timeout=60))
        conn.request('GET',(u.path.rstrip('/') or '')+f'/v1/jobs/{jid}',headers={'Authorization':'Bearer '+a.token}); r=conn.getresponse(); state=json.loads(r.read())
        print('Status:',state.get('status'),flush=True)
        if state.get('status')=='failed': sys.exit('Render failed: '+str(state.get('error')))
        if state.get('status')=='completed': break
        time.sleep(max(.5,a.poll))
    conn.close(); conn=(http.client.HTTPSConnection(u.hostname,u.port,timeout=300) if u.scheme=='https' else http.client.HTTPConnection(u.hostname,u.port or 80,timeout=300))
    conn.request('GET',(u.path.rstrip('/') or '')+f'/v1/jobs/{jid}/output',headers={'Authorization':'Bearer '+a.token}); r=conn.getresponse()
    if r.status!=200: sys.exit(f'Output download failed: HTTP {r.status} {r.read().decode(errors="replace")}')
    dest=Path(a.output); dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('wb') as out:
        while chunk:=r.read(CHUNK): out.write(chunk)
    print('Export saved:',dest.resolve()); print('Verified result:',json.dumps(state.get('result',{}),indent=2))
    conn.close()
if __name__=='__main__': main()

# Hero Studio export integration contract

The editor remains a control/preview surface. Export must hand off a stable project snapshot and original media to the independent local Hero Render Engine; the browser must not encode the final video or buffer full media files in RAM.

## Handoff sequence

1. Freeze a project snapshot at the moment Export is requested.
2. Resolve every clip's source ID to its original media file in Hero's project storage.
3. Build API manifest `{ project, settings, sources[] }`. Each `sources[]` entry contains `id`, `name`, `kind`, `size`, and preferably `sha256`.
4. POST multipart form to `http://127.0.0.1:8080/v1/jobs` with `manifest` and one `media` part per source. Each upload filename must begin with the matching source ID. Stream each file in bounded chunks; do not read it wholly into memory.
5. Poll `GET /v1/jobs/{job_id}`. Display `queued`, `claimed`, `staging`, `rendering`, `completed`, or `failed`; never invent a percentage because the current engine only reports stages.
6. On `completed`, GET `/v1/jobs/{job_id}/output` and stream the response into Hero's output storage. Verify the file exists and retain the engine's verification metadata.
7. Only then show Export complete and expose the output to the user. On failure, show the actual error and preserve the project/media.

## Security and platform

The API requires `Authorization: Bearer <token>`; token is generated locally in `.runtime/access-token.txt`. Do not put the token in page source, localStorage, or a public URL. A native desktop/Android host adapter must keep the token private and proxy requests. API currently binds to localhost; LAN access requires a separate authenticated, encrypted host configuration and is intentionally not enabled by default.

## Current gap

Android 0.5.12 has no adapter that submits this manifest and media, polls the job, and retrieves the output. This document is the precise integration contract; it does not imply that app integration is already complete.

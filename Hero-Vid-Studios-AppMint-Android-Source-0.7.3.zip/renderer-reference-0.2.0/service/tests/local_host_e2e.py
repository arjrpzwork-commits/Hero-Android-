#!/usr/bin/env python3
"""End-to-end local API + queue worker + streaming export-client test."""
from __future__ import annotations
import json, os, socket, subprocess, sys, tempfile, time, urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
FIXTURE=ROOT/'engine/tests/fixtures/test-source.mp4'
TOKEN='hero-local-e2e-test-token'

def main():
    with tempfile.TemporaryDirectory(prefix='hero-local-e2e-') as td:
        base=Path(td); data=base/'data'; media=base/'media'; media.mkdir(); (media/'video-fixture.mp4').write_bytes(FIXTURE.read_bytes())
        size=(media/'video-fixture.mp4').stat().st_size
        project={'format':'HeroBrowserSource','version':2,'trackCounts':{'video':1,'audio':1},'clips':[{'id':'v1','source':'video-fixture','kind':'video','track':0,'start':0,'in':0,'out':2,'gain':1,'mute':False,'fadeIn':0,'fadeOut':0}],'sources':[{'id':'video-fixture','name':'video-fixture.mp4','size':size,'kind':'video','duration':2}],'settings':{},'original':True}
        settings={'container':'mp4','video':True,'video_codec':'h264','audio_codec':'aac','width':640,'height':360,'fps_num':30,'fps_den':1,'video_bitrate':3000000,'audio_bitrate':192000,'audio_sample_rate':48000,'audio_bit_depth':24,'master_gain':1.0,'include_original_audio':True,'duration':2.0}
        manifest={'project':project,'settings':settings,'sources':[{'id':'video-fixture','name':'video-fixture.mp4','kind':'video','size':size}]}
        manifest_path=base/'manifest.json'; manifest_path.write_text(json.dumps(manifest))
        with socket.socket() as s: s.bind(('127.0.0.1',0)); port=s.getsockname()[1]
        env=os.environ.copy(); env.update({'HERO_RENDER_DATA':str(data),'HERO_ENGINE_BIN':str(ROOT/'engine/build/hero-native-engine'),'HERO_RENDER_TOKEN':TOKEN,'PYTHONPATH':str(ROOT)})
        api_log=(base/'api.log').open('w'); worker_log=(base/'worker.log').open('w')
        api=subprocess.Popen([sys.executable,'-m','uvicorn','service.app:app','--host','127.0.0.1','--port',str(port)],cwd=ROOT,env=env,stdout=api_log,stderr=subprocess.STDOUT)
        worker=subprocess.Popen([sys.executable,str(ROOT/'worker/worker.py')],cwd=ROOT,env=env,stdout=worker_log,stderr=subprocess.STDOUT)
        try:
            url=f'http://127.0.0.1:{port}'
            for _ in range(100):
                try:
                    with urllib.request.urlopen(url+'/health',timeout=1): break
                except Exception: time.sleep(.1)
            else: raise RuntimeError('Local API did not start')
            output=base/'verified-output.mp4'; client_env=env.copy(); client_env['HERO_RENDER_TOKEN']=TOKEN
            subprocess.run([sys.executable,str(ROOT/'tools/hero_export.py'),'--url',url,'--manifest',str(manifest_path),'--media-dir',str(media),'--output',str(output),'--poll','0.2'],cwd=ROOT,env=client_env,check=True,timeout=90)
            probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=codec_name,width,height,avg_frame_rate','-of','json',str(output)],text=True))
            stream=probe['streams'][0]
            assert (stream['codec_name'],stream['width'],stream['height'],stream['avg_frame_rate'])==('h264',640,360,'30/1')
            assert output.stat().st_size>0
            print('PASS: local API -> disk-backed queue -> native render -> verified streamed MP4 download')
        finally:
            for p in (worker,api):
                p.terminate()
            for p in (worker,api):
                try: p.wait(timeout=5)
                except subprocess.TimeoutExpired: p.kill(); p.wait()
            api_log.close(); worker_log.close()

if __name__=='__main__': main()

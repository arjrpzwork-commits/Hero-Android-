#!/usr/bin/env python3
"""Local end-to-end test for API -> disk-backed queue -> worker -> FFmpeg -> download."""
from __future__ import annotations
import json, os, subprocess, sys, tempfile, time, unittest
from pathlib import Path
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[2]
DATA = Path(tempfile.mkdtemp(prefix='hero-render-api-test-'))
os.environ['HERO_RENDER_DATA'] = str(DATA)
os.environ['HERO_RENDER_TOKEN'] = 'local-test-token-not-for-deployment'
sys.path.insert(0, str(ROOT))
from service.app import app  # noqa: E402

class RenderApiE2E(unittest.TestCase):
    def test_authenticated_upload_render_verify_download(self):
        video = ROOT / 'engine/tests/fixtures/test-source.mp4'
        audio = ROOT / 'engine/tests/fixtures/test-tone.wav'
        sources = [
            {'id':'video-fixture','name':video.name,'kind':'video','size':video.stat().st_size},
            {'id':'audio-fixture','name':audio.name,'kind':'audio','size':audio.stat().st_size},
        ]
        project = {
            'format':'HeroBrowserSource','version':2,'trackCounts':{'video':1,'audio':1},'sources':sources,
            'clips':[
                {'id':'v1','source':'video-fixture','kind':'video','track':0,'start':0,'in':0,'out':2,'gain':1,'mute':False,'fadeIn':0,'fadeOut':0},
                {'id':'a1','source':'audio-fixture','kind':'audio','track':0,'start':0,'in':0,'out':1.25,'gain':0.8,'mute':False,'fadeIn':0.05,'fadeOut':0.05},
            ]
        }
        settings = {'container':'mp4','video':True,'video_codec':'h264','audio_codec':'aac','width':640,'height':360,
                    'fps_num':30,'fps_den':1,'video_bitrate':3000000,'audio_bitrate':192000,
                    'audio_sample_rate':48000,'audio_bit_depth':24,'master_gain':1.0,
                    'include_original_audio':True,'duration':2.0}
        env = os.environ.copy(); env['HERO_ENGINE_BIN'] = str(ROOT/'engine/build/hero-native-engine')
        worker = subprocess.Popen([sys.executable,str(ROOT/'worker/worker.py')],cwd=ROOT,env=env,
                                  stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        try:
            with TestClient(app) as client:
                self.assertEqual(client.get('/health').status_code,200)
                self.assertEqual(client.get('/v1/jobs/not-a-job').status_code,401)
                headers={'Authorization':'Bearer local-test-token-not-for-deployment'}
                files=[('media',('video-fixture.mp4',video.read_bytes(),'video/mp4')),
                       ('media',('audio-fixture.wav',audio.read_bytes(),'audio/wav'))]
                response=client.post('/v1/jobs',headers=headers,
                    data={'manifest':json.dumps({'project':project,'settings':settings,'sources':sources})},files=files)
                self.assertEqual(response.status_code,202,response.text)
                job_id=response.json()['job_id']; deadline=time.time()+60
                while time.time()<deadline:
                    status=client.get(f'/v1/jobs/{job_id}',headers=headers).json()
                    if status['status'] in ('completed','failed'): break
                    time.sleep(0.2)
                self.assertEqual(status['status'],'completed',json.dumps(status))
                self.assertEqual(status['result']['verification']['streams'][0]['codec_name'],'h264')
                output=client.get(f'/v1/jobs/{job_id}/output',headers=headers)
                self.assertEqual(output.status_code,200,output.text[:500])
                self.assertGreater(len(output.content),1000)
        finally:
            worker.terminate(); worker.wait(timeout=10)

if __name__ == '__main__': unittest.main(verbosity=2)

from __future__ import annotations
import hashlib, hmac, json, os, re, sqlite3, uuid
from pathlib import Path
from typing import Any
from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse

DATA = Path(os.environ.get('HERO_RENDER_DATA', '/var/lib/hero-render'))
DB = DATA / 'jobs.sqlite3'
TOKEN = os.environ.get('HERO_RENDER_TOKEN', '')
app = FastAPI(title='Hero Render Engine API', version='0.2.0', docs_url=None, redoc_url=None)


def db():
    DATA.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute('''CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY, status TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP, manifest TEXT NOT NULL, result TEXT,
      error TEXT, bytes_in INTEGER DEFAULT 0, output_name TEXT)''')
    c.commit()
    return c


def auth(value: str | None):
    if not TOKEN:
        raise HTTPException(503, 'Render service is not configured with an access token')
    if not value or not hmac.compare_digest(value, f'Bearer {TOKEN}'):
        raise HTTPException(401, 'Unauthorized')


def safe_id(value: str) -> str:
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,80}', value):
        raise HTTPException(400, f'Invalid source id: {value}')
    return value


@app.get('/health')
def health():
    return {'service': 'Hero Render Engine', 'version': '0.2.0', 'status': 'ready'}


@app.post('/v1/jobs', status_code=202)
async def submit_job(manifest: str = Form(...), media: list[UploadFile] = File(...), authorization: str | None = Header(default=None)):
    auth(authorization)
    try:
        spec = json.loads(manifest)
    except Exception:
        raise HTTPException(400, 'manifest must be valid JSON')
    if not isinstance(spec, dict) or not isinstance(spec.get('project'), dict) or not isinstance(spec.get('settings'), dict):
        raise HTTPException(400, 'manifest requires project and settings objects')
    sources = spec.get('sources')
    if not isinstance(sources, list) or not sources:
        raise HTTPException(400, 'manifest.sources must be a non-empty list')
    expected = {}
    for s in sources:
        if not isinstance(s, dict) or not all(k in s for k in ('id', 'name', 'kind', 'size')):
            raise HTTPException(400, 'Each source requires id, name, kind, and size')
        sid = safe_id(str(s['id']))
        if sid in expected: raise HTTPException(400, 'Duplicate source id')
        size = int(s['size'])
        if size <= 0: raise HTTPException(400, 'Source size must be positive')
        expected[sid] = (size, s)
    job_id = str(uuid.uuid4())
    job_dir = DATA / 'jobs' / job_id
    incoming = job_dir / 'incoming'
    incoming.mkdir(parents=True, mode=0o700)
    seen, total = set(), 0
    try:
        for upload in media:
            sid = safe_id(Path(upload.filename or '').stem)
            if sid not in expected or sid in seen:
                raise HTTPException(400, f'Unexpected or duplicate media upload: {sid}')
            size, meta = expected[sid]
            path = incoming / f'{sid}.media'
            digest = hashlib.sha256(); written = 0
            with path.open('wb') as out:
                while True:
                    chunk = await upload.read(1024 * 1024)
                    if not chunk: break
                    written += len(chunk); total += len(chunk)
                    out.write(chunk); digest.update(chunk)
            if written != size: raise HTTPException(400, f'Size mismatch for {sid}: expected {size}, received {written}')
            if meta.get('sha256') and digest.hexdigest().lower() != str(meta['sha256']).lower():
                raise HTTPException(400, f'SHA-256 mismatch for {sid}')
            seen.add(sid)
        if seen != set(expected):
            raise HTTPException(400, f'Missing media sources: {sorted(set(expected)-seen)}')
        c = db()
        c.execute('INSERT INTO jobs(id,status,manifest,bytes_in) VALUES(?,?,?,?)',
                  (job_id, 'queued', json.dumps(spec), total)); c.commit(); c.close()
    except Exception:
        import shutil; shutil.rmtree(job_dir, ignore_errors=True); raise
    return {'job_id': job_id, 'status': 'queued', 'status_url': f'/v1/jobs/{job_id}', 'architecture': 'independent-server-render'}


@app.get('/v1/jobs/{job_id}')
def job_status(job_id: str, authorization: str | None = Header(default=None)):
    auth(authorization); c = db(); row = c.execute('SELECT * FROM jobs WHERE id=?', (job_id,)).fetchone(); c.close()
    if not row: raise HTTPException(404, 'Job not found')
    out: dict[str, Any] = {'job_id': row['id'], 'status': row['status'], 'created_at': row['created_at'], 'updated_at': row['updated_at'], 'uploaded_bytes': row['bytes_in']}
    if row['error']: out['error'] = row['error']
    if row['result']: out['result'] = json.loads(row['result'])
    if row['status'] == 'completed': out['download_url'] = f"/v1/jobs/{job_id}/output"
    return out


@app.get('/v1/jobs/{job_id}/output')
def download_output(job_id: str, authorization: str | None = Header(default=None)):
    auth(authorization); c = db(); row = c.execute('SELECT status,output_name FROM jobs WHERE id=?', (job_id,)).fetchone(); c.close()
    if not row: raise HTTPException(404, 'Job not found')
    if row['status'] != 'completed' or not row['output_name']: raise HTTPException(409, 'Render is not complete')
    path = DATA / 'jobs' / job_id / 'output' / row['output_name']
    if not path.is_file(): raise HTTPException(410, 'Output is no longer available')
    return FileResponse(path, filename=row['output_name'], media_type='application/octet-stream')

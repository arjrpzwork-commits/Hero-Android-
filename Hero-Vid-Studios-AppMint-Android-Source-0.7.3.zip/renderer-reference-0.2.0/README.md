# Hero Render Engine 0.2.0

A separate, server-side rendering system for Hero Vid Studios. It performs rendering away from Android phones, desktop devices, browsers, HTML, and editor UI. It does not modify or connect to the Hero Vid Studios app in this milestone.

## Included
- Local macOS/Linux host manager (no Docker or paid cloud service required)
- Disk-streaming export client for manifest + original-media submission and output retrieval
- Local bearer-token generation, separate API/worker processes, status and stop commands
- Versioned HTTP job API (submit, status, download)
- Authenticated upload with byte-count and optional SHA-256 verification
- Separate queue worker and isolated per-job native engine process
- Existing Hero C++/FFmpeg composition engine and ffprobe output verification
- Docker Compose deployment baseline

## Quick local host (macOS/Linux)
1. Install Python 3.10+, CMake 3.20+, a C++20 compiler, Boost headers, FFmpeg and ffprobe.
2. Run `python3 host/hero_host.py setup`, then `python3 host/hero_host.py start`.
3. The service binds to `127.0.0.1:8080`; data stays under `data/`. See `HOST-QUICKSTART.md`.
4. Submit a manifest and original media with `tools/hero_export.py`; see `HOST-QUICKSTART.md`.

Windows is not supported by this native engine build yet because its C++ process launcher uses POSIX APIs. The editor Export button is not yet wired; see `EXPORT-INTEGRATION.md`.

## Docker deployment (optional)
1. Copy `.env.example` to `.env` and replace the token with a long random secret.
2. Run `docker compose up --build -d` on a Linux server with Docker Engine and Compose.
3. Put the API behind HTTPS. Do not expose unauthenticated port 8080 to the public internet.
4. See `docs/ARCHITECTURE.md` for the API contract, manifest, security, and quality policy. No fixed application-level upload-size, duration, resolution, frame-rate, or bitrate ceiling is configured. Uploads stream to disk-backed job storage; source media is staged in bounded chunks. There is no fixed per-source byte ceiling in the native engine.

This package is source and deployment infrastructure, not a hosted service or APK. It does not yet connect to the editor. Cloud infrastructure, domain, storage, authentication integration, and production operations must be provisioned before real users can submit jobs.

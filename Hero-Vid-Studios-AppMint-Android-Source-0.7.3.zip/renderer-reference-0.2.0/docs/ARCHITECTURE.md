# Hero Render Engine 0.1.1 — architecture and contract

## Separation boundary

This is a standalone server-side render system. It has no Android, desktop, browser, HTML, WebView, editor UI, or device-rendering dependency. The editor is not modified or connected in this milestone. A client submits a complete project snapshot, original media, and explicit settings over HTTPS; a server worker performs the render on server compute. The client is only a future job-control/upload/download surface.

```text
Future client (not included) --HTTPS--> Render API --> durable job queue
                                               |              |
                                               |              v
                                               |        isolated worker
                                               |              |
                                               |       native Hero engine
                                               |              |
                                               |       FFmpeg + ffprobe
                                               |              |
                                               +<-- status -- verified output
```

## API v1

All endpoints except `/health` require `Authorization: Bearer <HERO_RENDER_TOKEN>`.

- `POST /v1/jobs` — multipart form with `manifest` JSON and one or more `media` files. Returns `202` and a job ID.
- `GET /v1/jobs/{job_id}` — status, failure reason, and verified metadata.
- `GET /v1/jobs/{job_id}/output` — downloads the completed output.

Manifest shape:

```json
{
  "project": { "format": "HeroBrowserSource", "version": 2, "clips": [], "sources": [] },
  "settings": {
    "container": "mp4", "video": true, "video_codec": "h264", "audio_codec": "aac",
    "width": 1920, "height": 1080, "fps_num": 30, "fps_den": 1,
    "video_bitrate": 16000000, "audio_bitrate": 320000,
    "audio_sample_rate": 96000, "audio_bit_depth": 24,
    "master_gain": 1.0, "duration": 60.0
  },
  "sources": [
    { "id": "source_1", "name": "camera-original.mp4", "kind": "video", "size": 123456, "sha256": "optional-lowercase-hex" }
  ]
}
```

Each uploaded media filename must start with its source ID, e.g. `source_1.mp4`. The exact byte count is checked; optional SHA-256 is checked before queueing. Project clip `source` IDs must match the manifest source IDs. Settings are passed unchanged to the native engine; unsupported settings/codecs fail rather than silently selecting a substitute.

## Job states

`queued -> claimed -> staging -> rendering -> completed | failed`

The first release reports stage-level status. The current C++ engine does not expose frame-level progress or cancellation, so the service does not pretend it does. These are follow-on engine capabilities, not export duration or file-size ceilings.

## Isolation and data handling

Each job has a unique workspace on the persistent render-data volume. API and worker are separate containers sharing only that private volume. The application sets no fixed upload-byte, project-duration, resolution, frame-rate, or bitrate ceiling. The inherited 1 TiB per-source guard has also been removed. Uploads are consumed in bounded chunks and persisted to disk-backed job workspaces. The physical capacity of the attached storage and the selected FFmpeg encoder/container remain real infrastructure/format constraints; they are not product-imposed export caps. Bearer authentication is mandatory. Containers run non-root, read-only root filesystems, no added Linux capabilities, and no-new-privileges. The API does not expose arbitrary filesystem paths. A production deployment still needs HTTPS termination, secret rotation, per-user authorization, rate limiting against abuse, retention/deletion policy, encrypted storage/backups, malware/media parser hardening, and infrastructure capacity monitoring. The included compose file is a deployment starting point, not a claim of production certification.

## Quality contract and current limits

The native engine validates format correctness and uses ffprobe after rendering to verify implemented stream metadata. It imposes no fixed product ceilings on project duration, frame rate, resolution, or bitrate. A render is marked completed only after native verification succeeds. This does not mean all transformations are lossless: compositing/scaling/re-encoding and audio mixing/resampling change media by design. No silent downgrade is allowed. Actual codec availability depends on the FFmpeg build in the deployed image; the engine errors when an encoder is unavailable. Physical storage and compute capacity remain properties of the hosting infrastructure, not hard-coded export caps.

The inherited engine currently supports basic timeline clip composition and audio mixing, not the complete professional editor feature set. Transitions, titles, effects, color management, HDR, proxies, waveform caches, frame-accurate progress, cancellation, and full audio automation are not implemented. No claim of complete-editor parity is made.

## Build/license gate

The container installs Debian's FFmpeg package and builds original Hero C++ code. Before public/commercial distribution, audit the exact deployed FFmpeg version, configure flags, linked libraries, codecs, and all applicable source/notice obligations. The earlier development FFmpeg build was configured with GPL and libx264; this package does not claim LGPL-only status or legal clearance. Preserve the Boost Software License 1.0 notice for Boost Property Tree use.

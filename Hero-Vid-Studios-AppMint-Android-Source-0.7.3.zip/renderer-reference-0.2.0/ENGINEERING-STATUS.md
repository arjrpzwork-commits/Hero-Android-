# Hero Render Engine 0.2.0 — engineering status

## Implemented in this milestone
- Existing C++ native render engine builds in Release mode on the current Linux build environment.
- Existing offline MP4 H.264/AAC smoke render passes.
- Existing WAV PCM 96 kHz / 24-bit smoke render passes.
- Local macOS/Linux host manager added: creates local Python environment, builds native engine, generates local bearer token, starts/stops API and worker separately, reports service health.
- API and worker now both initialize the SQLite schema, removing a startup race when the worker launches before the API.
- Streaming export client added: uploads manifest and source files in bounded 1 MiB chunks, polls job states, streams completed output to disk.
- Full local API -> queue -> native render -> output download path tested with an actual 2-second MP4 fixture; output verified as H.264, 640x360, 30 fps with AAC audio.
- Local end-to-end regression test added at `service/tests/local_host_e2e.py`.

## Not yet implemented
- Hero Studio / Android 0.5.12 Export button is not connected to this service. A native host adapter must serialize the editor project and original media to the documented manifest/API contract.
- The API intentionally binds to localhost. Authenticated LAN control from the phone to the computer is a separate integration step and must be secured before enabling it.
- Windows host support is not implemented; native engine currently uses POSIX process APIs.
- The native engine still uses local FFmpeg/ffprobe binaries and has only basic timeline composition/audio mixing. It is not yet a full implementation of all editor effects, titles, transitions, or advanced color workflows.
- No Docker build, production deployment, or public endpoint was tested or created.
- Commercial redistribution requires a specific FFmpeg build/configuration and license audit. No legal clearance is claimed.

## Cost and resource policy
- No paid cloud service or subscription is required for local host rendering.
- No fixed application-level upload-size, project-duration, resolution, frame-rate, or bitrate caps are introduced.
- Actual host compute, available memory, disk space, operating-system limits, and codec/container support remain physical constraints.
- The current service writes uploaded sources and outputs to disk-backed per-job workspaces; media upload and download clients stream in bounded chunks.

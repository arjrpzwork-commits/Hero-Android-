from __future__ import annotations
import base64, json, os, sqlite3, subprocess, time, uuid
from pathlib import Path

DATA = Path(os.environ.get('HERO_RENDER_DATA', '/var/lib/hero-render'))
ENGINE = os.environ.get('HERO_ENGINE_BIN', '/usr/local/bin/hero-native-engine')
CHUNK = 256 * 1024

def connect():
    DATA.mkdir(parents=True, exist_ok=True)
    c=sqlite3.connect(DATA/'jobs.sqlite3', timeout=30); c.row_factory=sqlite3.Row
    # Worker may start before the API container/process initializes the queue.
    c.execute('''CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY, status TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP, manifest TEXT NOT NULL, result TEXT,
      error TEXT, bytes_in INTEGER DEFAULT 0, output_name TEXT)''')
    c.commit()
    return c

def set_status(job, status, error=None, result=None, output_name=None):
    c=connect(); c.execute('UPDATE jobs SET status=?,error=?,result=?,output_name=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',
      (status,error,json.dumps(result) if result is not None else None,output_name,job)); c.commit(); c.close()

def call(proc, method, params):
    req={'id':str(uuid.uuid4()),'method':method,'params':params}
    proc.stdin.write(json.dumps(req,separators=(',',':'))+'\n'); proc.stdin.flush()
    line=proc.stdout.readline()
    if not line: raise RuntimeError('Native engine terminated without a response')
    response=json.loads(line)
    if response.get('error'): raise RuntimeError(response['error'].get('message','Engine request failed'))
    return response['result']

def render(job):
    job_dir=DATA/'jobs'/job['id']; incoming=job_dir/'incoming'; output=job_dir/'output'; output.mkdir(exist_ok=True)
    spec=json.loads(job['manifest']); sources=spec['sources']; settings=spec['settings']; project=spec['project']
    set_status(job['id'],'staging')
    work_dir=job_dir/'work'; work_dir.mkdir(parents=True,exist_ok=True)
    child_env=os.environ.copy(); child_env['TMPDIR']=str(work_dir)
    engine_log = (job_dir / 'native-engine.log').open('a', encoding='utf-8')
    proc=subprocess.Popen([ENGINE],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=engine_log,text=True,bufsize=1,cwd=str(job_dir),env=child_env)
    try:
        pid=call(proc,'beginProject',{'project':project,'settings':settings})['projectId']
        for source in sources:
            sid=str(source['id']); path=incoming/f'{sid}.media'; size=path.stat().st_size
            call(proc,'beginSource',{'projectId':pid,'sourceId':sid,'name':source['name'],'size':size,'kind':source['kind']})
            with path.open('rb') as f:
                seq=0
                while chunk:=f.read(CHUNK):
                    call(proc,'appendSourceChunk',{'projectId':pid,'sourceId':sid,'sequence':seq,'base64':base64.b64encode(chunk).decode('ascii')}); seq+=1
            call(proc,'finishSource',{'projectId':pid,'sourceId':sid})
        set_status(job['id'],'rendering')
        result=call(proc,'renderProject',{'projectId':pid,'settings':settings})
        src=Path(result['outputPath']); name=f"hero-render-{job['id']}.{settings.get('container','mp4')}"; dst=output/name
        src.replace(dst)
        # Return only output metadata and explicit requested settings, never engine-internal paths.
        safe_result={'message':result.get('message'),'bytes':dst.stat().st_size,'verification':result.get('verification'),'requestedSettings':result.get('requestedSettings')}
        set_status(job['id'],'completed',result=safe_result,output_name=name)
    finally:
        try: proc.stdin.close()
        except Exception: pass
        try: proc.wait(timeout=10)
        except subprocess.TimeoutExpired: proc.kill(); proc.wait()
        engine_log.close()

def main():
    DATA.mkdir(parents=True,exist_ok=True)
    while True:
        c=connect(); row=c.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY created_at LIMIT 1").fetchone()
        if row:
            c.execute("UPDATE jobs SET status='claimed',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='queued'",(row['id'],)); c.commit()
        c.close()
        if not row: time.sleep(1); continue
        try: render(dict(row))
        except Exception as e: set_status(row['id'],'failed',error=str(e)[:4000])

if __name__=='__main__': main()
